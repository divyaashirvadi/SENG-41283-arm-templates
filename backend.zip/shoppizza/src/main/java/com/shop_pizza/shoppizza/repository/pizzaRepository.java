package com.shop_pizza.shoppizza.repository;

import com.shop_pizza.shoppizza.model.pizzaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface pizzaRepository extends JpaRepository<pizzaEntity,Long> {
}
