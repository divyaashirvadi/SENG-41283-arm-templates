package com.shop_pizza.shoppizza.controller;

import com.shop_pizza.shoppizza.model.pizzaEntity;
import com.shop_pizza.shoppizza.repository.pizzaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class pizzaController {
    @Autowired
    com.shop_pizza.shoppizza.repository.pizzaRepository pizzaRepository;

    @PostMapping("/newUser")
    public pizzaEntity createNewUser(@RequestBody pizzaEntity pizzaEntity ){
        return pizzaRepository.save(pizzaEntity);
    }

    @GetMapping("/all")
    public List<pizzaEntity> getAll(){return pizzaRepository.findAll();
    }
}
