package com.shop_pizza.shoppizza.service.impl;

import com.shop_pizza.shoppizza.exception.ResourceNotFoundException;
import com.shop_pizza.shoppizza.model.pizzaEntity;
import com.shop_pizza.shoppizza.repository.pizzaRepository;
import com.shop_pizza.shoppizza.service.pizzaService;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.file.ReadOnlyFileSystemException;

public class pizzaImpl implements pizzaService {
    @Autowired
    pizzaRepository pizzaRepository;

    @Override
    public pizzaEntity getuserbyId(Long id) {
        return pizzaRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("pizzaEntity","userId",id));
    }
}
