package com.shop_pizza.shoppizza.service;

import com.shop_pizza.shoppizza.model.pizzaEntity;

public interface pizzaService {
    pizzaEntity getuserbyId(Long id);
}
