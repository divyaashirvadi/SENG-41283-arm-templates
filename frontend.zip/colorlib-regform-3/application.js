var restBaseUrl = "http://localhost:8080/";

var app = angular.module("myApp",[]);
app.controller('MainController',['$scope', 'pizzaService', function($scope, pizzaService){
   
    $scope.username='';
    $scope.email='';
    $scope.phone='';

    $scope.user_details = [];

    $scope.submitUsers = function () {
        var pizzaEntity = {username: $scope.username,email: $scope.email,phone:$scope.phone};

       pizzaService.newPizza(pizzaEntity, function (result) {
            alert('New user added with ID:'+result.Id);
            $scope.getAll();
            $scope.username = '';
            $scope.email = '';
            $scope.phone = '';

        });
    };

    $scope.getAll = function () {
        pizzaService.getAll(function (result) {
            $scope.user_details = result;
        });
    }

    $scope.getAll();

}]);

function getReq(method, url, data, params){
    var req = {
        method: method,
        url: restBaseUrl+url,
        data: data,
        params: params
    }
    return req;
}

app.factory('pizzaFactory', ['$http', function ($http) {
    var pizzaFactory = {};

    pizzaFactory.newPizza = function (pizza) {
        return $http(getReq('POST', 'newUser', pizza, ''));
    }

    pizzaFactory.getAll = function () {
        return $http(getReq('GET', 'all', '', ''));
    }

    return pizzaFactory;
}]);

app.service('pizzaService', ['pizzaFactory', function (pizzaFactory) {
    this.newPizza = function (pizza, callback) {
        pizzaFactory.newPizza(pizza)
            .then(function (response) {
                callback(response.data);
            }, function (error) {
                console.log(error);
                callback(error);
            });
    }

    this.getAll = function (callback) {
        pizzaFactory.getAll()
            .then(function (response) {
                callback(response.data);
            }, function (error) {
                console.log(error);
                callback(error);
            });
    }
}]);
